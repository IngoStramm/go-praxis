<?php
require_once 'documento.php';